#!/usr/bin/python3

# Important Libraries
import pyglet
import numpy

# Our Hero Class
class Player:
	def __init__(self, sprites={},
					   buildSprite=None,
					   playerClass="tank",
					   mode="idle",
					   speed=0.05,
					   scale=0.15,
					   loop=True,
					   x=380,
					   y=250,
					   direction = numpy.array([0,-1])):

		print('player->sprites',sprites)
		# Store the sprites, and the sprite building function
		self.sprites	  = sprites
		self.buildSprite  = buildSprite
		self.playerSprite = None

		# Some basic settings
		self.animationSpeed = speed
		self.animationScale = scale
		self.animationLoop	= loop
		self.animationX		= x
		self.animationY		= y
		self.playerClass	= playerClass
		self.mode			= mode

		# Build the starting character sprite
		self.changeSprite()

	# Build the initial character
	def changeSprite(self, mode=None, facing=None):
		if mode is not None:
			self.mode = mode
		if facing is not None:
			self.facing = facing
		if self.playerSprite is not None:
			self.animationX = self.playerSprite.x
			self.animationY = self.playerSprite.y
		self.playerSprite = self.buildSprite(self.sprites,
											 self.playerClass,
											 self.mode,
											 self.facing,
											 self.animationSpeed,
											 self.animationScale,
											 self.animationLoop,
											 self.animationX,
											 self.animationY)

	# Move the character
	def movement(self, t=0, keyTracking={}):
		modes = []
		if keyTracking != {}:
			for key in keyTracking:
				if key in keyMappings:
					modes.append(keyMappings[key])
		if 'right' in modes:
			self.playerSprite.x = self.playerSprite.x + 3
			if 'run' in modes:
				self.playerSprite.x = self.playerSprite.x + 6
			if self.mode != 'Run' or self.facing != 'Right':
				self.changeSprite('Run', 'Right')
		elif 'left' in modes:
			self.playerSprite.x = self.playerSprite.x - 3
			if 'run' in modes:
				self.playerSprite.x = self.playerSprite.x - 6
			if self.mode != 'Run' or self.facing != 'Left':
				self.changeSprite('Run', 'Left')
		elif self.mode != 'Idle' and modes == []:
				self.changeSprite('Idle', self.facing)

	# Draw our character
	def draw(self, t=0, keyTracking={}, *other):
		self.movement(t, keyTracking)
		self.playerSprite.draw()
