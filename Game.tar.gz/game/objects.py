#Van Wirebach, 237008
#objects class to handle all sprites that are objects
#tank player, enemies, crates, etc
import sprites
import pyglet
import random
import numpy
import time
import animation

soundExplosion = pyglet.media.load('sounds/explosion.wav', streaming=False)
#soundExplosion.play()
soundShot = pyglet.media.load('sounds/tank_reload.wav', streaming=False)
soundHealthUp = pyglet.media.load('sounds/healthUp.wav', streaming=False)

playerScore = 0
print(playerScore)
def getPlayerScore():
	return playerScore

def addPlayerScore(amt):
	global playerScore
	playerScore += amt

#global var for explosions
explosions = {}

def getExplosions():
	#print('getting explosions')
	removes = []
	for exp,Time in explosions.items():
		diff = time.time() - Time
		if diff > 1:
			removes.append(exp)
		#print(exp,diff)
	return explosions.keys()
	#new = {key: val for key, val in explosions if key not in removes}
	#return new.keys()

smokes = []
def getSmokes():
	return smokes

def isAnyCollision(curr, others):
	for obj in others:
		if curr.collider.isCollision(obj.collider):
			return True
	return False

class Shooter:
	def __init__(self, projectile,img,offsetX=0, offsetY=0, reloadTime = 2, speed=1.5):
		#projectile is an Object class
		self.projectile = projectile
		self.offsetX = offsetX
		self.offsetY = offsetY
		self.canShoot = True
		self.rounds = []
		self.img = img
		self.bulletLifeSpan = 10
		self.reloadTime = reloadTime
		self.lastShot = time.time() - self.reloadTime
		self.speed = speed
	
	def update(self):
		for Round in self.rounds:
			rot = Round.sprite.rotation
			#angle from pointing up
			rot = (rot - 90) % 360
			rot = (rot * -1) % 360
			radians = numpy.deg2rad(rot)
			x = numpy.cos(numpy.deg2rad(rot))
			y = numpy.sin(numpy.deg2rad(rot))
			speed = self.speed
			#Round.update(time, xDist = speed*(x - Round.sprite.x), yDist = speed*(y - Round.sprite.y))
			#Check for destroyed bullet
			Round.update(xDist = speed*x, yDist = speed*y)
			if Round.timeAlive > self.bulletLifeSpan:
				Round.destroy()
				#print(Round.name, 'should be deleted')
		#remove destroyed bullets
		self.rounds = [bullet for bullet in self.rounds if not bullet.selfDestruct]
			#print(Round.timeAlive, 'time bullet alive')
	
	def shoot(self,x,y,rotation=0):
		#can shoot
		if time.time() - self.lastShot >= self.reloadTime:
			soundShot.play()

			self.lastShot = time.time()
			#print('shooting angle is ',rotation)
			#create instance of projectile which is an object
			angle = (rotation + 180) % 360
			rot = (angle - 270) % 360
			rot = (rot * -1) % 360
			radians = numpy.deg2rad(rot)
			dirX = numpy.cos(numpy.deg2rad(rot))
			dirY = numpy.sin(numpy.deg2rad(rot))
			bullet = self.projectile(img=self.img,x=x - dirX*self.offsetX, y=y- dirY*self.offsetY, name="bullet", Type="Projectile", points=0)
			bullet.rotate(angle)
			self.rounds.append(bullet)
			#print('number of bullets:',len(self.rounds))

def addGreenBarrel():
	x = random.randint(0,64*8)
	y = random.randint(0,64*8)
	gbImg = pyglet.resource.image("images/objects/barrelGreen_top.png")
	temp = Object(gbImg,x,y, name="greenBarrel", isShooter=False, Type="GreenBarrel" )
	return temp

def addEnemy():
	enemyImg = pyglet.resource.image("images/characters/tank_red.png")
	x = 64*4
	#randomly spawn high or low
	y = 50
	if random.randint(0,1)==1:
		y = 64*8 - 50
	temp = Object(enemyImg,x,y, name="enemy" + str(random.randint(0,100)), isShooter=True, Type="Tank", reloadSpeed=5, bulletSpeed = 1, points=1000)
	return temp

def getAllObjects(width=800, height=600, numCrates=2, numEnemies=2, numGreenBarrels = 2, numBarricades=2):
	output = []
	#get player tank
	player = sprites.loadPlayer()
	output.append(Object(player,50,50, name="Player Tank", Type="Tank",reloadSpeed = 0.1, isShooter=True))
	#create enemies
	enemyImg = pyglet.resource.image("images/characters/tank_red.png")
	for i in range(numEnemies):
		x = random.randint(100,width)
		y = random.randint(100,height)
		temp = Object(enemyImg,x,y, name="enemy"+str(i), isShooter=True, Type="Tank", reloadSpeed=6, bulletSpeed = 1, points=1000)
		print(isAnyCollision(temp,output))
		while isAnyCollision(temp,output):
			print('spawn collision')
			x = random.randint(0,width)
			y = random.randint(0,height)
			temp.update(xDist = x - temp.sprite.x, yDist = y - temp.sprite.y)
		output.append(temp)

	#create green barrels
	for i in range(numGreenBarrels):
		x = random.randint(0,width)
		y = random.randint(0,height)
		gbImg = pyglet.resource.image("images/objects/barrelGreen_top.png")
		temp = Object(gbImg,x,y, name="greenBarrel"+str(i), isShooter=False, Type="GreenBarrel" )
		output.append(temp)
	
	#create barricade
	for i in range(numBarricades):
		x = random.randint(60,width)
		y = random.randint(60,height)
		bImg = pyglet.resource.image("images/objects/barricadeMetal.png")
		temp = Object(bImg,x,y, name="barricade"+str(i), isShooter=False, Type="Wall" )
		output.append(temp)

	#get crates
	crateImg = pyglet.resource.image("images/objects/crateWood.png")
	for i in range(numCrates):
		x = random.randint(60,width)
		y = random.randint(60,height)
		temp =Object(crateImg,x,y, name="crate"+str(i), Type="Crate", health=2)
		while (isAnyCollision(temp,output)):
			print('spawn collision')
			x = random.randint(0,width)
			y = random.randint(0,height)
			temp.update(xDist = x - temp.sprite.x, yDist = y - temp.sprite.y)

		output.append(temp)
		#check if bad spot
	return output

class Object:
	class Collider:
		def __init__(self,obj,blx,bly,width,height ,Type="wall", name='Object'):
			self.width = width*0.75
			self.height = height*0.75

			self.blx = blx - width//2
			self.bly = bly - height//2

			self.name = name
			self.obj = obj
			self.type = Type

		def updatePos(self, newX, newY):
			self.blx = newX - self.obj.img.width//2
			self.bly = newY - self.obj.img.height//2

		def isCollision(self, other,newX=0, newY=0):
			#debug with red square
			debug = False
			blx = self.blx + newX
			bly = self.bly + newY
			urx = blx + self.width
			ury = bly + self.height
			if debug:
				square = pyglet.resource.image("images/effects/redSquare.jpg")
				square = pyglet.sprite.Sprite(square,blx,bly)
				square.draw()

			otherBX = other.blx
			otherBY = other.bly
			otherTX = other.blx + other.width
			otherTY = other.bly + other.height
			
			if urx >= otherBX and blx <= otherTX and ury >= otherBY and bly <= otherTY:
				return True

		def onCollide(self,other):
			#print(self.name,"collided with",other.name)
			#stop from moving through
			if other.type != "Projectile":
				self.obj.undo()
			if self.type in ["Tank", "Crate", "Explosive"] and other.type == "Projectile":
				self.obj.takeDamage(1)
			if self.type == "Projectile":
				self.obj.destroy()
			if self.type == "Tank" and other.type == "GreenBarrel":
				self.obj.heal(1)
				soundHealthUp.play()
				print("heal")
			if self.type == "GreenBarrel" and other.type == "Tank":
				self.obj.destroy()

	#####################
	####END of Colldier REgion###
	###############################

	#init for object
	def __init__(self,img,x,y, isCollider=True, isShooter=False, reloadSpeed = 3, bulletSpeed = 1.5, health=3, name="Object", Type="Wall", points = 200):
		self.startTime = time.time()
		self.timeAlive = 0
		self.img = img
		self.img.anchor_x = img.width // 2
		self.img.anchor_y = img.height // 2
		self.x = x
		self.y = y
		self.lastX = x
		self.lastY = y
		self.sprite = pyglet.sprite.Sprite(img,x,y)
		self.health=health
		self.isCollider = isCollider
		self.name = name
		self.type= Type

		if self.type == "Tank":
			smoke = animation.loadSmoke(x = self.sprite.x, y=self.sprite.y)
			self.smoke = smoke

		self.points = points
		self.selfDestruct = False
		if isCollider:
			self.collider = Object.Collider(self,x,y,img.width,img.height, name=name, Type=Type)
		self.isShooter = isShooter
		if isShooter:
			bulletImg = pyglet.resource.image("images/objects/bullet.png")
			self.shooter = Shooter(Object,bulletImg, offsetX=40, offsetY=40, speed=bulletSpeed,reloadTime = reloadSpeed)
	
	def update(self, rotation=0, xDist=0, yDist=0):
		if self.type=="Tank":
			self.smoke.draw()
			self.smoke.x = self.sprite.x
			self.smoke.y = self.sprite.y
		self.timeAlive = time.time() - self.startTime
		#print('updating object', self.name)
		if rotation!=0:
			#print(rotation, type(rotation), 'rotation')
			var = self.sprite.rotation + rotation
			self.sprite.update(rotation = var)
		if xDist != 0 or yDist != 0:
			self.lastX = self.sprite.x
			self.lastY = self.sprite.y
			newPosX = self.sprite.x + xDist
			newPosY = self.sprite.y + yDist
			self.sprite.update(x=self.sprite.x + xDist, y=self.sprite.y + yDist)
			self.collider.updatePos(newPosX,newPosY)
		if self.isShooter:
			#print('updating shooter too')
			self.shooter.update()
	
	def undo(self):
		self.sprite.update(x=self.lastX, y=self.lastY)
	
	def forward(self,dist):
		#print(self.name,'is moving forward')
		#rotation is degrees CW from 0,-1 (down)
		rot = self.sprite.rotation
		#angle from 1,0 vector
		rot = (rot - 270) % 360
		rot = (rot * -1) % 360
		#print(rot)
		radians = numpy.deg2rad(rot)
		x = numpy.cos(numpy.deg2rad(rot))
		y = numpy.sin(numpy.deg2rad(rot))
		#print('rotation:',rot)
		self.update(xDist=x*dist,yDist=y*dist)

	def rotate(self, degrees):
		self.update(rotation=degrees)
	
	def takeDamage(self,dmg):
		self.health-=dmg
		if self.health<=0:
			self.destroy()
	
	def heal(self,amt):
		self.health += amt

	def destroy(self):
		if self.name != "bullet":
			print("destroying",self.name)
		self.selfDestruct = True
		expSprite = animation.loadExplosion(x = self.sprite.x, y=self.sprite.y)
		explosions[expSprite] = time.time()
		addPlayerScore(self.points)
		#make explosion sound
		soundExplosion.play()
		print('boom')

	def draw(self):
		self.sprite.draw()
		'''
		if self.name == "Player Tank":
			smoke = animation.loadSmoke(x = self.sprite.x, y=self.sprite.y)
			smokes.append(smoke)
			'''
		if self.isShooter:
			for bullet in self.shooter.rounds:
				bullet.draw()
