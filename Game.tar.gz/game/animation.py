#Van Wirebach, 237008
import pyglet, os

def loadExplosion(filepath="images/effects/explosion", x=10, y=10):
	#print(os.listdir(filepath))
	result = []
	for File in os.listdir(filepath):
		result.append(pyglet.resource.image(filepath+"/"+File))
	x = buildAnim(result, animationLoop = False, animationX = x, animationY = y)
	return x

def loadSmoke(filepath="images/effects/twinkle", x=10, y=10):
	#print(os.listdir(filepath))
	result = []
	for File in os.listdir(filepath):
		result.append(pyglet.resource.image(filepath+"/"+File))
	x = buildAnim(result, animationLoop = True, animationSpeed = 0.2,animationX = x, animationY = y)
	return x

# Build and return a configured sprite
def buildAnim(sprites=[], animationSpeed=0.05, animationScale=1, animationLoop=True,
				animationX=10, animationY=10):

	# Grab the correct sequence of images
	playerSequence = sprites

	# Build the pyglet animation sequence
	playerAnimation = pyglet.image.Animation.from_image_sequence(playerSequence,
																 animationSpeed,
																 animationLoop)
	# Create the sprite from the animation sequence
	playerSprite = pyglet.sprite.Sprite(playerAnimation,
										x=animationX,
										y=animationY)
	# Set the player's scale
	playerSprite.scale = animationScale

	return playerSprite

if __name__ == "__main__":
	imgs = loadExplosion()
	imgs.draw()
	print(imgs)
