#Van Wirebach, 237008
#controller class takes in object and does AI or I/O to move it
import time,math
import random
import pyglet

tankMoving = pyglet.media.Player()
tankMoving = pyglet.media.Player()
tankMoving.queue(pyglet.media.load("sounds/tank_moving.wav", streaming=True))
tankMoving.eos_action = 'loop'
tankMoving.loop = True
#tankMoving.play()
tankMovingPlaying = True

# Define the Keyboard mappings
from pyglet.window import key
keyMappings = {key.LSHIFT: 'run',    key.RSHIFT: 'run',
               key.LALT:   'attack', key.RALT:   'attack',
               key.LCTRL:  'shoot',  key.RCTRL:  'shoot',
               key.SPACE:  'jump',
               key.RIGHT:  'right',
               key.LEFT:   'left',
               key.UP:     'up',
               key.DOWN:   'down'}
class Controller:
	def __init__(self,obj):
		self.obj = obj
		#variable to use with phrase building
		self.forward = 0
		self.forwardInc = 200
		self.backward = 0 
		self.backwardInc = 100

		self.left = 0
		self.right = 0
		self.turnInc = 40
		self.shoot = False
	
	def update(self, time, Input=None,deltaX = 0, deltaY=0, deltaRot=0):
		pass

class PlayerController(Controller):

	def update(self, Input={}):
		#phrase building
		if self.forward > 0:
			self.obj.forward(1)
			self.forward = self.forward - 1
		elif self.backward > 0:
			self.obj.forward(-1)
			self.backward = self.backward - 1
		
		if self.left > 0:
			self.obj.rotate(-1)
			self.left = self.left - 1
		elif self.right >0:
			self.obj.rotate(1)
			self.right = self.right - 1

		if self.shoot:
			self.obj.shooter.shoot(self.obj.sprite.x, self.obj.sprite.y, rotation=self.obj.sprite.rotation)
			self.shoot = False

	def readPhrase(self, phrase):
		print("phrase is",phrase)
		if phrase == "forward":
			self.backward = 0
			self.forward = self.forward + self.forwardInc
		elif phrase == "backward":
			self.forward = 0
			self.backward = self.backward + self.backwardInc
		elif phrase == "left":
			self.right = 0
			self.left = self.left + self.turnInc
		elif phrase == "right":
			self.left = 0
			self.right = self.right + self.turnInc
		elif phrase == "shoot":
			self.shoot = True

#AI to control enemy tanks
class AI(Controller):
	def __init__(self,obj, period=10):
		Controller.__init__(self,obj)
		self.time = time.time()
		self.period = period
		self.mode = "TURN"

	def update(self, Input=None):
		x1 = self.obj.sprite.x
		y1 = self.obj.sprite.y
		x2 = Input.sprite.x
		y2 = Input.sprite.y
		turnSpeed = 0.4
		
		#change mode
		if time.time() - self.time > self.period:
			self.time = time.time()
			#print("CHANGING MODE")
			if self.mode == "TURN":
				self.mode = "MOVE"
				self.period = random.randint(1,5)
			else:
				self.mode = "TURN"
				self.period = random.randint(2,7)

		if self.mode == "TURN":
			#print("enemy turning")
			#find angle to player
			x = x2 - x1
			y = y2 - y1
			rads = math.atan2(y,x)
			deg = math.degrees(rads) % 360
			currRot = (self.obj.sprite.rotation - 270) % 360
			currRot = (currRot * -1) % 360
			diff = currRot - deg 
			if diff < 0:
				diff = -1 * (diff % 360)
			if abs(diff) > 5:
				#turn to player
				if diff > 0:
					self.obj.rotate(turnSpeed)
				else:
					self.obj.rotate(-1*turnSpeed)
			else:
				self.obj.shooter.shoot(self.obj.sprite.x, self.obj.sprite.y, rotation=self.obj.sprite.rotation)
			#print('deg, currRot, diff',deg, currRot, diff)
		else:
			#move
			#print("enemy moving")
			self.obj.forward(0.35)

