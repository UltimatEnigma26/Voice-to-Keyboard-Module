#Van Wirebach, 237008
#Proj 2: Tanks
#layout.py
#handles tile generation and drawing the ground
#TODO add game music here in init
from pprint import pprint
import random
import pyglet, sys
import objects as obJects

#first letter: g|s|t grass | sand | transition
#second letter: p|r plain | road 
#next two letters: 
	# PP plain
	# NS | EW North South | East West
	# Cardinals in NESW order
	# T + NSEW T split with North South...
	# CC cross
	#for plain transition give grass sand (ex EW is grass on east, sand on west

example = '''
gppp gres trwe srnw sppp
gppp grns tpwe sres srew
gppp grne trwe srtn srsw
gppp gppp tpwe sppp srns
'''

class Level:
	def __init__(self, objects=[]):
		example1 = '''
gppp gres trwe srnw sppp sppp srns tpew
gppp grns tpwe sres srew srew srtw tpew
gppp grne trwe srtn srsw sppp srns tpew
gppp gppp tpwe sppp srns sppp srns tpew
grew grew trwe srew srcc srew srnw tpew
gppp gppp tpwe sppp srns sppp sppp tpew
gppp gppp tpwe sppp srte srew srsw tpew
gppp gres trwe srew srtw sppp srns tpew
		'''
		example2 = '''
sppp sres srew srnw sppp sppp srns tpew
sppp srns sppp sres srew srew srtw tpew
sppp srne srts srtn srsw sppp srns tpew
sppp sppp srns sppp srns sppp srns tpew
srew srew srcc srew srtn srew srtn trew
sppp sppp srns sppp sppp sppp sppp tpew
sppp sppp srns sppp sres srew srsw tpew
sppp sres srtn srew srtw sppp srns tpew
		'''
		plainGrass = '''
gppp gppp gppp gppp gppp gppp gppp gppp
gppp gppp gppp gppp gppp gppp gppp gppp
gppp gppp gppp gppp gppp gppp gppp gppp
gppp gppp gppp gppp gppp gppp gppp gppp
gppp gppp gppp gppp gppp gppp gppp gppp
gppp gppp gppp gppp gppp gppp gppp gppp
gppp gppp gppp gppp gppp gppp gppp gppp
gppp gppp gppp gppp gppp gppp gppp gppp
		'''
		plainSand = '''
sppp sppp sppp sppp sppp sppp sppp sppp
sppp sppp sppp sppp sppp sppp sppp sppp
sppp sppp sppp sppp sppp sppp sppp sppp
sppp sppp sppp sppp sppp sppp sppp sppp
sppp sppp sppp sppp sppp sppp sppp sppp
sppp sppp sppp sppp sppp sppp sppp sppp
sppp sppp sppp sppp sppp sppp sppp sppp
sppp sppp sppp sppp sppp sppp sppp sppp
		'''
		Map = random.choice([example1,example2, plainGrass, plainSand])
		#Map = example2
		self.grid = self.board2grid(board=Map)
		self.objects = objects

	def test(self):
		print("this is an instance of the level class")

	# A function to cleate a useful grid from the board file...
	#grid is name of every file where tile is
	def board2grid(self,board, tilepath='images/tiles', returnSize=False):
		lines = board.split('\n')[1:-1]
		grid = []
		for line in lines:
			temp = line.split(' ')
			grid.append(temp)
		#pprint(grid)
		for row in range(len(grid)):
			for col in range(len(grid[row])):
				name = grid[row][col]
				#add 0 or 1 for variations
				if name[1:] == 'ppp':
					name += str(random.randint(0,1))
				#add possible dirt transitions
				if name[:2] == 'tr':
					if random.randint(0,1) == 0:
						name += "dirt"
				#add possible curvey variation t junction
				if name[2:] == 'cc':
					if random.randint(0,1) == 0:
						name += "curve"
				
				path = tilepath + "/" + name + ".png"
				try:
					grid[row][col] = pyglet.image.load(path)
				except:
					print("file not found", path)
		self.grid = grid
		return grid

	# Here is a complete drawBoard function which will draw the terrain.
	# Lab Part 1 - Draw the board here
	def drawBoard(self, delta_x=0, delta_y=0, height=600, width=800, x=0,y=0):
		#width and height are of the screen
		
		grid=self.grid
		w = int(width/(len(grid[0])))
		h = int(height/(len(grid)))
		'''
		print(width,height)
		print(w)
		print(h)
		'''
		
		x = 0
		y = height - h
		for row in range(len(grid)):
			for col in range(len(grid[row])):
				#col is an image
				image = grid[row][col]
				grid[row][col].anchor_x = 0
				grid[row][col].anchor_y = 0
				posX = x + h*col #-1*col
				posY = y + -1*row*w #+1*row

				image.blit(posX, posY,height=h, width=w)
				#level[row][col].blit(col*width+delta_x,row*height+delta_y, height=height, width=width)

	def addEnemy(self):
		print("adding enemy")
		enemy = obJects.addEnemy()
		self.objects.append(enemy)
		return enemy
	def addGreenBarrel(self):
		print('adding green barrel')
		barrel = obJects.addGreenBarrel()
		self.objects.append(barrel)
		return barrel

	def draw(self, t=0, width=800, height=600, keyTracking={}, mouseTracking=[]):
		#print('drawing board',type(self))
		#print('self',self)
		#print('t',t)
		#print('width',width)
		self.drawBoard(width=width, height=height)
		#get all bullets to check for collisions
		allColliders = []
		for obj in self.objects:
			if obj.isShooter:
				for bullet in obj.shooter.rounds:
					allColliders.append(bullet)
			if obj.isCollider:
				allColliders.append(obj)

		for i in range(len(allColliders)-1):
			obj = allColliders[i]
			for other in allColliders[i+1:]:
				if obj.collider.isCollision(other.collider):
					obj.collider.onCollide(other.collider)
					other.collider.onCollide(obj.collider)

		#remove destroyed objects
		self.objects = [obj for obj in self.objects if not obj.selfDestruct]

		#draw all objects
		for obj in self.objects:
			obj.draw()
			obj.update()

if __name__ == "__main__":

	level1 = Level()
	grid = level1.board2grid(example)
	pprint(grid)
	width = 800
	height = 600
	caption = "Layout test"
	window = pyglet.window.Window(width=width, height=height, resizable=False, caption=caption)
	level1.drawBoard(grid)
	pyglet.app.run()
