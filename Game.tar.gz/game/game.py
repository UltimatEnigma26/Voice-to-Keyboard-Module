#!/usr/bin/python3 -B

# Important Libraries
import pyglet
import random
import time, sys, importlib
import sprites, objects, controller

soundFart = pyglet.media.load('sounds/fart.wav', streaming=False)
farted = False

# Our world that we will draw via pyglet
class Game:

	# Update the world time based on time elapsed in the real world
	# since we started the Game Class.
	def updateClock(self, dt):
		self.worldTime = time.time() - self.startTime

	# Initialize and run our environment
	def __init__(self, width=800, height=600, caption="Wirebach Game", level=None, resizable=True, controllers=None):
		# Music in the Background
		self.sentence = ""
		self.sound = pyglet.media.Player()
		self.sound.queue(pyglet.media.load("sounds/bgMusic.mp3", streaming=True))
		self.sound.eos_action = 'loop'
		self.sound.loop = True
		self.sound.play()
		self.soundPlaying = True

		self.playerAlive = True
		self.controllers = controllers
		self.playerCont =  controllers[0]

		self.spawnRate = 60
		# Store the dimensions of the world
		self.width	= width
		self.height = height

		# Lets track what keys are being pressed
		self.keyTracking   = {}
		self.mouseTracking = []

		# Count screenshots
		self.screenshot = 0

		# Build the OpenGL / Pyglet Window
		self.window = pyglet.window.Window(width=self.width, height=self.height, resizable=resizable, caption=caption)

		# Fix transparent issue...
		pyglet.gl.glEnable(pyglet.gl.GL_BLEND)
		pyglet.gl.glBlendFunc(pyglet.gl.GL_SRC_ALPHA, pyglet.gl.GL_ONE_MINUS_SRC_ALPHA)

		# Store the current level of the game
		self.level = level

		# Lets set a global clock
		self.worldTime = 0.0
		self.startTime = time.time()

		# Schedule a Clock to update the time
		pyglet.clock.schedule_interval(self.updateClock, 1.0/60.0)

		# Handle Key Presses in our World
		@self.window.event
		def on_key_press(symbol, modifiers):
			#enter is 65293
			#space is 32?
			#reset sentence
			print(str(symbol))
			if str(symbol) == "32" or str(symbol) == "100" or str(symbol) == "116":
				if str(symbol) == "100":
					self.sentence = self.sentence+"d"
				elif str(symbol) == "116":
					self.sentence = self.sentence + "t"
				print("space")
				self.playerCont.readPhrase(self.sentence)
				self.sentence = ""
			else:
				self.sentence = self.sentence + chr(symbol)

			if symbol == pyglet.window.key.END:
				self.screenshot = self.screenshot + 1
				pyglet.image.get_buffer_manager().get_color_buffer().save(sys.argv[-1]+'.'+str(self.screenshot)+'.png')
			self.keyTracking[symbol] = modifiers

		# Handle Key Releases in our World
		@self.window.event
		def on_key_release(symbol, modifiers):
			if symbol in self.keyTracking:
				del(self.keyTracking[symbol])

		# Allow for resizing the game window
		@self.window.event
		def on_resize(width, height):
			self.width = width
			self.height = height

		def drawScore():
			window = self.window
			player = self.playerCont.obj
			hp = player.health
			text = "Score: " + str(objects.getPlayerScore()) 
			text2 = "Health: " + str(hp)
			text3 = "Time: " + str(int(self.worldTime))
			text4 = "Commands: " + self.sentence

			label = pyglet.text.Label(text, x=window.width - 60, y=window.height - 40, anchor_x='center')
			label2 = pyglet.text.Label(text2, x=window.width - 60, y=window.height - 80, anchor_x='center')
			label3 = pyglet.text.Label(text3, x=window.width - 60, y=window.height - 120, anchor_x='center')
			label4 = pyglet.text.Label(text4, x=window.width/2 - 100, y=window.height*0.9, anchor_x='left')

			label.draw()
			label2.draw()
			label3.draw()
			label4.draw()

		def quitScreen():
			global farted
			if not farted:
				farted = True
				soundFart.play()
				print('farted')

			self.window.clear()
			window = self.window
			score = "Good Try. You Scored: " + str(objects.getPlayerScore())
			label = pyglet.text.Label(score, x=window.width//2, y=window.height//2, anchor_x='center')
			label.draw()

			player = self.playerCont.obj
			player.sprite.draw()

		# Event Handler for drawing the screen
		@self.window.event
		def on_draw():

			# Clear the window (a good way to start things)
			self.window.clear()

			# Lets draw all of the individual objects, these objects
			# need to have a draw function that takes in worldTime as
			# a variable.
			if self.level is not None:
				#print('game-> self.level',type(self.level))
				#print(self.level)
				self.level.draw(width=self.window.width, height=self.window.height)
				if self.worldTime > self.spawnRate:
					self.spawnRate += self.spawnRate
					enemy = self.level.addEnemy()
					self.level.addGreenBarrel()
					self.controllers.append(controller.AI(enemy))

			#handle player and enemy movt
			for cont in controllers:
				#print(type(self.keyTracking), self.keyTracking)
				if cont.obj.name == "Player Tank":
					cont.update(Input=self.keyTracking)
					if cont.obj.selfDestruct:
						#print("player dead, score is ", objects.getPlayerScore())
						quitScreen()

				else:
					if not cont.obj.selfDestruct:
						cont.update(self.playerCont.obj)
			#print(self.keyTracking)
			
			#draw explosions
			for anim in objects.getExplosions():
				#print(anim)
				anim.draw()
			#draw smoke
			for anim in objects.getSmokes():
				anim.draw()

			drawScore()

# Load in any requested objects from the command then, then start the game.
if __name__ == '__main__':

	# Retrieve the levelname from the command line, default to mylevel
	levelName = "layout"

	# Update path for python libraries so we can import python files in the
	# level directory (such as player, enemies, etc.)
	#sys.path.append("./"+levelName)

	print('Loading Level...')
	level =  getattr(importlib.import_module(levelName), 'Level')
	print(type(level),'level type')

	character =  getattr(importlib.import_module("character"), 'Player')

	objs = objects.getAllObjects(width=64*8,height=64*8, numGreenBarrels=random.randint(2,4), numBarricades=random.randint(5,10))
	objs[0].sprite.update(rotation=270)
	
	playerCont = controller.PlayerController(objs[0])
	conts = [playerCont]

	#add enemy AI controller
	for obj in objs:
		if "enemy" in obj.name:
			enemyCont = controller.AI(obj)
			conts.append(enemyCont)

	print('Starting Game...')
	myLevel = level(objs)
	grid = myLevel.grid
	rows = len(grid)
	cols = len(grid[0])
	print(rows,cols)
	myGame = Game(64*cols, 64*rows, "SI460 Game", level=myLevel, controllers=conts)
	pyglet.app.run()
