#interpreter.py
#Converts string of text (received from a Vosk Speech to Text) into functions
#	Functions will print text for now but eventually will be keyboard signals
#Van Wirebach, 237008
from num2words import num2words   #needed to convert numbers to digits
from words2num import words2num		#actually needed for this since vosk returns "one"
import pyautogui
#Checks if a string is the english spelling of a number (Ex: "one hundred and fifty nine", "two")
#Return True, words2num(words) if the string is a word that can be converted to a number using words2num()
#False, None otherwise
def isEngNum(words):
	try:
		num = words2num(words)
		return True, num
	except:
		return False, None

class Emulator:

	def __init__(self, hotkeys = {}):
		self.hotkeys = hotkeys
		self.specialkeys = ['\t', '\n', '\r', ' ', '!', '"', '#', '$', '%', '&', "'", '(',
		')', '*', '+', ',', '-', '.', '/', '0', '1', '2', '3', '4', '5', '6', '7',
		'8', '9', ':', ';', '<', '=', '>', '?', '@', '[', '\\', ']', '^', '_', '`',
		'a', 'b', 'c', 'd', 'e','f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o',
		'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', '{', '|', '}', '~',
		'accept', 'add', 'alt', 'altleft', 'altright', 'apps', 'backspace',
		'browserback', 'browserfavorites', 'browserforward', 'browserhome',
		'browserrefresh', 'browsersearch', 'browserstop', 'capslock', 'clear',
		'convert', 'ctrl', 'ctrlleft', 'ctrlright', 'decimal', 'del', 'delete',
		'divide', 'down', 'end', 'enter', 'esc', 'escape', 'execute', 'f1', 'f10',
		'f11', 'f12', 'f13', 'f14', 'f15', 'f16', 'f17', 'f18', 'f19', 'f2', 'f20',
		'f21', 'f22', 'f23', 'f24', 'f3', 'f4', 'f5', 'f6', 'f7', 'f8', 'f9',
		'final', 'fn', 'hanguel', 'hangul', 'hanja', 'help', 'home', 'insert', 'junja',
		'kana', 'kanji', 'launchapp1', 'launchapp2', 'launchmail',
		'launchmediaselect', 'left', 'modechange', 'multiply', 'nexttrack',
		'nonconvert', 'num0', 'num1', 'num2', 'num3', 'num4', 'num5', 'num6',
		'num7', 'num8', 'num9', 'numlock', 'pagedown', 'pageup', 'pgdn',
		'pgup', 'playpause', 'prevtrack', 'print', 'printscreen', 'prntscrn',
		'prtsc', 'prtscr', 'return', 'right', 'scrolllock', 'select', 'separator',
		'shift', 'shiftleft', 'shiftright', 'sleep', 'space', 'stop', 'subtract', 'tab',
		'up', 'volumedown', 'volumemute', 'volumeup', 'win', 'winleft', 'winright', 'yen',
		'command', 'option', 'optionleft', 'optionright']
		#These are the special keys in which people would need to press rather than write
		self.commands = {"ctrl" : 0, "alt": 0, "shift": 0}
		self.keyrelation = {'control': 'ctrl', 'period': '.', 'plus': '+', 'minus': '-', 'comma':',', 'semi': ';', 'colon':':', 'star':'*','exclamation':'!','ult':'alt', "back":"backspace", "mute":"volumemute", "screenshot":"prntscrn", "caps":"capslock", "louder":"volumeup","quieter":"volumedown", "next":"nexttrack", "pipe":"|", "apostrophe":"'", "quote":'"', "equal":"=", "lesser":'<', "greater":">", "carrot":"^", "hinting":"(", "hinted":")", "bracing":'[', 'braced':']', 'curling':'{', 'curled':'}', "at":"@", "pound":'#', "forward":'/', 'backward':"\\", "question":"?"}
		# These are the keys that otherwise would relate to the special keys if parsed but not spelled in a right manner, secondhand check to parsing

	#This will write anything that is not intended to be a command or hotkey, we can up the speed later
	def puts(self, info):
		pyautogui.write(info)
	
	#This will create a hotkey out of a list of characters or command characters. ASSUMES 'words' is list type
	def create_hotkey(self, key, words):
		for x in words:
			if x not in self.specialkeys:
				print("Invalid key for hotkey generation:", x, "Must be character, or within special-keys library \n", self.specialkeys, "\n\n\n")
			
		self.hotkeys[key] = words
		pass

	def execute_hotkey(self, key):
		try:
			pyautogui.hotkey(*self.hotkeys[key])
		except:
			print("Hotkey plug failed")
		pass
		
	#This will print out a command character on the keyboard
	def commandputs(self, info):
		realInfo = info
		if info in self.keyrelation:
			#info is a pseudo word
			realInfo = self.keyrelation[info]

		hotkey = False
		if self.commands["ctrl"] == 1 and realInfo != "ctrl":
			hotkey = True
			print("control is down, make a hotkey")

		#if key pressed is a toggler
		if realInfo in self.commands.keys():
			if self.commands[realInfo] == 0:
				#not currently pressed down
				if realInfo != "ctrl":
					pyautogui.keyDown(realInfo)
				print("pressing", realInfo, "down")
				self.commands[realInfo] = 1
			else:
				if realInfo != "ctrl":
					pyautogui.keyUp(realInfo)
				print("releasing", realInfo, "key up")
				self.commands[realInfo] = 0
		#info is a special key that doesn't toggle
		elif realInfo in self.specialkeys:
			if hotkey:
				pyautogui.hotkey('ctrl',realInfo)
			else:
				pyautogui.press(realInfo)
		else:
			print("Command Key not accepted, perhaps interpretation not in range of special keys. Try hotkey generation\n\n\n")
			pass



class Interpreter:
	def __init__(self, keyword, digits=True, commands=False, spaces = True, debug=False):
		self.key = keyword
		self.list = []
		self.debug = debug
		self.paused = False
		#Initialized Emulator
		self.Keyboard = Emulator() 
		#modes for toggling settings
		self.modes = {}
		self.modes['digits'] = digits
		self.modes['commands'] = commands
		self.modes['spaces'] = spaces
		#keyboard words are words that represent special keys on the keyboard (ctrl, space, etc)
		self.keyboardWords = []
		relations = self.Keyboard.keyrelation.keys()
		self.keyboardWords.extend(relations)
		specialkeys = ['alt','delete',
		'divide', 'down', 'end', 'enter', 'escape', 
		'home', 'insert', 
		'left', 
		'return', 'right', 
		'shift', 'space', 'tab',
		'up', 'win']
		self.keyboardWords.extend(specialkeys)
		self.keyboardWords.append('control')
		self.keyboardWords.append('space')
		self.keyboardWords.append('tab')
		self.keyboardWords.append('enter')
		self.keyboardWords.append('period')
		self.keyboardWords.append('comma')
		self.keyboardWords.append('plus')
		self.keyboardWords.append('minus')
		self.keyboardWords.append('semicolon')
		self.keyboardWords.append('colon')
		self.keyboardWords.append('shift')
		self.keyboardWords.append('ult')
		self.keyboardWords.append('delete')
		self.keyboardWords.append('star')
	
	def ReadFile(self):
		print("Reading ReadFile.txt")
		f = open("ReadFile.txt", "r")
		#change keyword
		first = f.readline()
		print("   ",first)
		keyword = first.split()[1]
		self.key = keyword

		#change modes default
		for mode in ["digits", "commands", "spaces"]:
			line = f.readline()
			print("   ",line)
			Bool = "True" in line
			self.modes[mode] = Bool

		#macros
		for line in f:
			print("   ",line)
		f.close()
		return
		
	#Interpret a string by tokenizing it then interpreting each token
	def interpret(self, string):
		#include spaces in tokens, will ignore in process() depending on spaces mode
		tokens = self.tokenize(string)
		print(tokens)
		self.enqueue(tokens)
		self.process()
	
	def get_modes(self):
		return list(self.modes.keys())

	def display_info(self):
		print("keyword =", self.key, end="	 ")
		for mode in self.modes:
			val = self.modes[mode]
			print(mode, "=", val, end="   ")
		print()

	#Internal function to convert a string into a list of strings (tokens) to be interpret
	#TODO tokenize a string such as "one hundred and fifty two plus seven" -> ["one hundred and fifty two", "plus", "seven"]
	#  Idea: iterate through tokens and try except until error to get biggest group, then join those elements into one
	def tokenize(self, string):
		tokens = string.replace(' ', '* *')
		tokens = tokens.split("*")
		output = []
		currNum = ""
		building = False
		
		for token in tokens:
			print()
			print('token:',token)
			print('isEngNum', isEngNum(token)[0])
			#check if already testing for english number
			if building:
				print("BUIDLING")
				#if next token continues valid english number
				if isEngNum(currNum + token)[0]:
					currNum = currNum + token
				else:
					#english number complete, make one token
					output.append(currNum)
					building = False
					currNum = ""
			#check for first occurance
			elif isEngNum(token)[0]:
				print('first number')
				building = True
				currNum = token
			else:
				print("not a num")
				building = False
				currNum = ""
				output.append(token)
		if building:
			print("building", currNum)
			output.append(currNum)
		print("tokenize()->",str(output))
		return output

	def tokenize(self,string):
		tokens = string.replace(' ', '* *')
		tokens = tokens.split("*")
		currNum = ""
		output = []
		for token in tokens:
			test = currNum + token
			if isEngNum(test)[0]:
				currNum = test
			else:
				if currNum != "":
					output.append(currNum)
					currNum = ""
				output.append(token)
		if currNum != "":
			output.append(currNum)
		return output

	#Internal function to add tokens to queue for interpretation
	#Can take a single token or a list of tokens
	def enqueue(self, tokens):
		if type(tokens) == type([]):
			for token in tokens:
				self.list.append(token)
		else:
			self.list.append(tokens)

	def process(self):
		prev = None
		prevIsKeyboard = False
		prevIsKey = False
		while(len(self.list)>0):
			curr = self.list.pop(0)
			#PAUSE CHECK
			if curr == "pause" and prev == self.key:
				if self.paused:
					self.paused = False
					print("no longer pausing, will listen again")
					continue
				else:
					self.paused = True
					print('paused, say "<keyword> pause" to continue')

			#SPACES CHECK
			if curr == " " and not self.modes['spaces'] or curr == " " and prevIsKeyboard: 
				print('skipping space')
				continue
			#try and get num from word
			isNum, num = isEngNum(curr)

			#print('popping', curr)
			#check for keyword, then move on while storing keyword in previous
			if curr == self.key:
				if prev == self.key:
					#special key TWICE -> wants that word normal
					self.send(self.key)
					prev = None  #don't want to remember prev now (key key control should not return key <ctrl>)
					continue
				else:	#first occurence of keyword
					prev = curr
					continue
			#MODES CHECK
			if curr in self.get_modes():
				#entered <key> <mode> to toggle mode
				if prev == self.key:
					self.toggle(curr)
					print(curr, 'mode changed to', self.modes[curr])
					prev = curr
					continue
				else:
					self.send(curr)
					prev = curr
					continue
			#KEYBOARD KEYS CHECK
			elif curr in self.keyboardWords:
				prevIsKey = prev == self.key
				#commands mode ON: need <keyword> to send WORD ('space', 'control', 'period', etc)
				if self.modes['commands']:		
					if prevIsKey:
						self.send(curr)
						prevIsKeyboard = False
						prev = curr
						continue
					else:												#No keyword before and commands mode ON -> send keyboard key
						self.sendKey(curr)
						prevIsKeyboard = True
						prev = curr
						continue
				#commands mode OFF: need <keyword> to send KEY (CTRL, SPACE, etc)
				else:
					if prevIsKey:		#Mode OFF but WAS key, send KEY
						self.sendKey(curr)
						prevIsKeyboard = True
						prev = curr
						continue
					else:
						self.send(curr)
						prevIsKeyboard = False
						prev = curr
						continue
			#HANDLING DIGITS
			elif isNum:
				#check digits mode
				if self.modes['digits']:
					self.send(str(num))
				else:
					self.send(curr)
				prev = curr
			#ALL OTHER NORMAL WORDS
			else:
				if curr != " ":
					prev = curr
				self.send(curr)
			#reset flag variables
			#print('reset')
			prevIsKey = False
		self.list = []

		#print()
		#print('all done')
		#print()
			
	def send(self,word):
		#print('returning',word)
		if not self.paused:
			self.Keyboard.puts(word)
	#	for letter in word:
	#		Emulator.puts(letter)

	#used for unique keyboard keys, send them instead of the word version
	def sendKey(self, keyboardKey):
		if not self.paused:
			self.Keyboard.commandputs(keyboardKey)

	def toggle(self, mode):
		self.modes[mode] = self.modes[mode] ^ True

def loopTest():
	x = 0
	while True:
		x += 1
		if x == 2:
			continue
		print(x)
		if x == 5:
			break

if __name__ == "__main__":
	inter = Interpreter("key")
	inter.display_info()
	while True:
		txtfile = open("speechtxt.txt", "r")
		text = txtfile.read()
		#Erase contents now
		txtfile.close()
		txtfile = open("speechtxt.txt", "w").close()
		if text == "quit":
			quit()
		inter.interpret(text)
