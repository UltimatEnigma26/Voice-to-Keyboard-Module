exports.printMsg = function() {
  console.log("This is a message from the Vosk package");
}
