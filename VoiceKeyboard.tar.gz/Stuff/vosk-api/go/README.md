See example subfolder for instructions how to use the module
