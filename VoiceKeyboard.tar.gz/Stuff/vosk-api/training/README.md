A proper simple setup to train a Vosk model

More documentation later
