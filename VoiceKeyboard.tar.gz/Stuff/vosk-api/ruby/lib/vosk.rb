class Vosk
  def self.hi
    puts "Hello world!"
  end
end
