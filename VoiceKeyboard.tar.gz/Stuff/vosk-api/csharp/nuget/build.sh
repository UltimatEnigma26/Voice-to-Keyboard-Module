mcs -out:lib/netstandard2.0/Vosk.dll -target:library src/*.cs
nuget pack
